/**
* The client is a leading manufacturing firm having around 1,50,000 employees. Client wants to know list of employees in each department.
* Most of the employees work in a singledepartment but some employees are shared between multiple departments.
* Some departments have supervisors and some departments have managers. Supervisors report to managers.
* Client wants a screen to find list of employees reporting directly to a given manager and through supervisors reporting to him. 
* Design the appropriate DB structure and the Employee list 
* Preferred : NodeJS, MongoDB.
* Time: 45 mins – 75 mins 
*/

const express = require('express');
// const bodyParser = require('body-parser');
const PORT = 3000;
const app = new express();
const employeeCollection = [
  { id: 1, name: 'Mohan', department: 'IT', isSupervisor: false, isManager: true, supervisorId: null, managerId: null },
  { id: 3, name: 'Amit', department: 'IT', isSupervisor: false, isManager: true, supervisorId: null, managerId: null },
  { id: 4, name: 'Sumit', department: 'IT', isSupervisor: false, isManager: false, supervisorId: 6, managerId: null },
  { id: 6, name: 'Ajit', department: 'IT', isSupervisor: true, isManager: false, supervisorId: null, managerId: 3 },
  { id: 7, name: 'Roy', department: 'IT', isSupervisor: false, isManager: false, supervisorId: 6, managerId: null },
  { id: 8, name: 'Latha', department: 'IT', isSupervisor: false, isManager: true, supervisorId: null, managerId: null },
  { id: 10, name: 'Kiran', department: 'IT', isSupervisor: false, isManager: false, supervisorId: 6, managerId: null },
  { id: 12, name: 'Tarang', department: 'IT', isSupervisor: true, isManager: false, supervisorId: 3, managerId: null },
  { id: 13, name: 'Zia', department: 'IT', isSupervisor: false, isManager: false, supervisorId: 6, managerId: null },
  { id: 16, name: 'Bindu', department: 'IT', isSupervisor: false, isManager: false, supervisorId: 6, managerId: null },
  { id: 2, name: 'Rohan', department: 'Operations', isSupervisor: false, isManager: false, supervisorId: 6, managerId: null },
  { id: 5, name: 'Ajay', department: 'Operations', isSupervisor: true, isManager: false, supervisorId: null, managerId: 8 },
  { id: 9, name: 'Prerna', department: 'Operations', isSupervisor: false, isManager: false, supervisorId: 5, managerId: null },
  { id: 17, name: 'Roy', department: 'Operations', isSupervisor: false, isManager: false, supervisorId: 5, managerId: null },
  { id: 11, name: 'Vimal', department: 'HRD', isSupervisor: true, isManager: false, supervisorId: null, managerId: null },
  { id: 18, name: 'Kiran', department: 'HRD', isSupervisor: false, isManager: false, supervisorId: 11, managerId: null },
  { id: 14, name: 'Abdul', department: 'Finance', isSupervisor: false, isManager: true, supervisorId: null, managerId: null },
  { id: 15, name: 'Nisar', department: 'Finance', isSupervisor: true, isManager: false, supervisorId: 14, managerId: null },
  { id: 16, name: 'Zia', department: 'Finance', isSupervisor: false, isManager: false, supervisorId: 15, managerId: null },
];


const connectDBGetData = () => {
  const dbStatusConnected = true;
  if(dbStatusConnected) {
    return employeeCollection;
  }
}

app.get("/", (req, res) =>{
  res.send(connectDBGetData());
 // res.send('OK');
  res.end();
});

/**
 * Client wants to know list of employees in each department.
 * http://localhost:3000/employees
 */
app.get("/employees/", (req, res) => {
  let respObj = {};
  const data = connectDBGetData();
  data.forEach(e=> {
    const eObj = {"Name": e.name, "ID": e.id};
    switch (e.department) {
      case 'IT':
        respObj['IT'] ? respObj['IT'].push(eObj) : ((respObj['IT'] = []), respObj['IT'].push(eObj));
        break;
      case 'Operations':
        respObj['Operations'] ? respObj['Operations'].push(eObj) : ((respObj['Operations'] = []), respObj['Operations'].push(eObj));
        break;
      case 'HRD':
        respObj['HRD'] ? respObj['HRD'].push(eObj) : ((respObj['HRD'] = []), respObj['HRD'].push(eObj));
        break;
      case 'Finance':
        respObj['Finance'] ? respObj['Finance'].push(eObj) : ((respObj['Finance'] = []), respObj['Finance'].push(eObj));
        break;
      default:
        break;
    }
  })
  res.send(respObj);
  res.end();
});

/**
 * Client wants to know list of employees only (leaf nodes, excluding managers, supervisors) in each department.
 * http://localhost:3000/employeesonly
 */
app.get("/employeesonly/", (req, res) => {
  let respObj = {};
  const data_ = connectDBGetData();
  const data = data_.filter((o) => o.isSupervisor === false && o.isManager === false);
  data.forEach(e=> {
    const eObj = {"Name": e.name, "ID": e.id};
    switch (e.department) {
      case 'IT':
        respObj['IT'] ? respObj['IT'].push(eObj) : ((respObj['IT'] = []), respObj['IT'].push(eObj));
        break;
      case 'Operations':
        respObj['Operations'] ? respObj['Operations'].push(eObj) : ((respObj['Operations'] = []), respObj['Operations'].push(eObj));
        break;
      case 'HRD':
        respObj['HRD'] ? respObj['HRD'].push(eObj) : ((respObj['HRD'] = []), respObj['HRD'].push(eObj));
        break;
      case 'Finance':
        respObj['Finance'] ? respObj['Finance'].push(eObj) : ((respObj['Finance'] = []), respObj['Finance'].push(eObj));
        break;
      default:
        break;
    }
  })
  res.send(respObj);
  res.end();
});

// let data_ = connectDBGetData();
// let  data = data_.filter(o => o.isSupervisor === true);
// console.log(data);


/**
 * Client wants to know list of Supervisors in each department.
 * http://localhost:3000/supervisors
 */
app.get("/supervisors/", (req, res) => {
  let respObj = {};
  const data_ = connectDBGetData();
  const data = data_.filter((o) => o.isSupervisor === true);
  data.forEach((e) => {
    const eObj = {"Name": e.name, "ID": e.id};
    switch (e.department) {
      case 'IT':
        respObj['IT'] ? respObj['IT'].push(eObj) : ((respObj['IT'] = []), respObj['IT'].push(eObj));
        break;
      case 'Operations':
        respObj['Operations'] ? respObj['Operations'].push(eObj) : ((respObj['Operations'] = []), respObj['Operations'].push(eObj));
        break;
      case 'HRD':
        respObj['HRD'] ? respObj['HRD'].push(eObj) : ((respObj['HRD'] = []), respObj['HRD'].push(eObj));
        break;
      case 'Finance':
        respObj['Finance'] ? respObj['Finance'].push(eObj) : ((respObj['Finance'] = []), respObj['Finance'].push(eObj));
        break;
      default:
        break;
    }
  });
  res.send({ Supervisors: respObj });
  res.end();
});

/**
 * Client wants to know list of Managers in each department.
 * http://localhost:3000/managers
 */
app.get('/managers/', (req, res) => {
  let respObj = {};
  const data_ = connectDBGetData();
  const data = data_.filter((o) => o.isManager === true);
  data.forEach((e) => {
    const eObj = {"Name": e.name, "ID": e.id};
    switch (e.department) {
      case 'IT':
        respObj['IT'] ? respObj['IT'].push(eObj) : ((respObj['IT'] = []), respObj['IT'].push(eObj));
        break;
      case 'Operations':
        respObj['Operations'] ? respObj['Operations'].push(eObj) : ((respObj['Operations'] = []), respObj['Operations'].push(eObj));
        break;
      case 'HRD':
        respObj['HRD'] ? respObj['HRD'].push(eObj) : ((respObj['HRD'] = []), respObj['HRD'].push(eObj));
        break;
      case 'Finance':
        respObj['Finance'] ? respObj['Finance'].push(eObj) : ((respObj['Finance'] = []), respObj['Finance'].push(eObj));
        break;
      default:
        break;
    }
  });
  res.send({ Managers: respObj });
  res.end();
});


/**
 * THIS LAST API I DID AFTER ZOOM DISCONNECT
 * 
 * 
 * Client wants a screen to find list of employees reporting directly to a given manager and through supervisors reporting to him.
 * http://localhost:3000/employeesBySupervisorName/:managerName e.g., http://localhost:3000/employeesBySupervisorName/Ajit or http://localhost:3000/employeesBySupervisorName/Ajay
 * 
 * Note: Didn't design (just missed to read and accomodate this use case) any employee reporting directly to Manager, all are reporting to Supervisors.
 * 
 * 
 * THIS LAST API I DID AFTER ZOOM DISCONNECT
 */
app.get("/employeesBySupervisorName/:supervisorName", (req, res) => {
  let respObj = {};
  let employees = [];
  const data_ = connectDBGetData();
  const supervisorName = req.params.supervisorName;
  const supervisorId = data_.find((o) => o.name === supervisorName).id;
  const data = data_.filter((o) => o.supervisorId === supervisorId);

  data.forEach(e=> {
    employees.push({"Employee Name": e.name, "ID": e.id});
  });

  let respObjKey = `Reports to Supervisor: ${supervisorName}, ID: ${supervisorId}`;
  respObj[respObjKey] = employees;

  res.send(respObj);
  res.end();
});

app.listen(PORT, ()=> console.log('Server listening at', PORT));
